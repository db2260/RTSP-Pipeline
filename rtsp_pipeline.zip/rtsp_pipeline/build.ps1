$ErrorActionPreference = "Stop"

New-Item -ItemType Directory -Force -Path build | Out-Null

g++ -std=c++17 -O2 -Wall -Wextra -pedantic `
    src/main.cpp `
    -lws2_32 `
    -o build/rtsp_live_view.exe

Write-Host "Built build/rtsp_live_view.exe"

