#include <atomic>
#include <cctype>
#include <chrono>
#include <csignal>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <map>
#include <sstream>
#include <stdexcept>
#include <string>
#include <thread>
#include <vector>

#if defined(_WIN32) || defined(_WIN64) || defined(__MINGW32__) || defined(__MINGW64__)
#define RTSP_LIVE_VIEW_WINDOWS 1
#endif

#ifdef RTSP_LIVE_VIEW_WINDOWS
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <winsock2.h>
#include <ws2tcpip.h>
using socket_t = SOCKET;
constexpr socket_t invalid_socket_value = INVALID_SOCKET;
#else
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <unistd.h>
using socket_t = int;
constexpr socket_t invalid_socket_value = -1;
#endif

namespace fs = std::filesystem;

std::atomic_bool g_running{true};

struct Config {
    std::string rtsp_url;
    fs::path rtsp_file = "stream_url.txt";
    std::string ffmpeg = "ffmpeg";
    std::string host = "0.0.0.0";
    int port = 8080;
    fs::path hls_dir = "out/hls";
    fs::path web_dir = "web";
    int segment_seconds = 1;
    int list_size = 4;
    int retry_seconds = 3;
};

static void close_socket(socket_t s) {
#ifdef RTSP_LIVE_VIEW_WINDOWS
    closesocket(s);
#else
    close(s);
#endif
}

static std::string shell_quote(const std::string& value) {
#ifdef RTSP_LIVE_VIEW_WINDOWS
    std::string out = "\"";
    for (char c : value) {
        if (c == '"') out += "\\\"";
        else out += c;
    }
    out += "\"";
    return out;
#else
    std::string out = "'";
    for (char c : value) {
        if (c == '\'') out += "'\\''";
        else out += c;
    }
    out += "'";
    return out;
#endif
}

static std::string content_type(const fs::path& path) {
    const auto ext = path.extension().string();
    if (ext == ".html") return "text/html; charset=utf-8";
    if (ext == ".css") return "text/css; charset=utf-8";
    if (ext == ".js") return "application/javascript; charset=utf-8";
    if (ext == ".m3u8") return "application/vnd.apple.mpegurl";
    if (ext == ".ts") return "video/mp2t";
    if (ext == ".json") return "application/json; charset=utf-8";
    return "application/octet-stream";
}

static std::string http_date() {
    return "Fri, 08 May 2026 00:00:00 GMT";
}

static std::string trim(std::string value) {
    const auto first = value.find_first_not_of(" \t\r\n");
    if (first == std::string::npos) return "";
    const auto last = value.find_last_not_of(" \t\r\n");
    return value.substr(first, last - first + 1);
}

static bool read_first_line(const fs::path& path, std::string& value) {
    std::ifstream file(path);
    if (!file) return false;
    std::getline(file, value);
    value = trim(value);
    return !value.empty();
}

static bool is_placeholder_rtsp_url(const std::string& value) {
    return value.find("user:pass@camera-host/path") != std::string::npos;
}

static bool safe_join(const fs::path& root, const std::string& request_path, fs::path& out) {
    std::string decoded = request_path;
    auto query = decoded.find('?');
    if (query != std::string::npos) decoded.resize(query);
    if (decoded.empty() || decoded == "/") decoded = "/index.html";

    fs::path relative;
    for (auto part : fs::path(decoded).relative_path()) {
        if (part == "..") return false;
        relative /= part;
    }

    out = fs::weakly_canonical(root / relative);
    auto canonical_root = fs::weakly_canonical(root);
    auto out_text = out.string();
    auto root_text = canonical_root.string();
#ifdef RTSP_LIVE_VIEW_WINDOWS
    for (auto& c : out_text) c = static_cast<char>(std::tolower(c));
    for (auto& c : root_text) c = static_cast<char>(std::tolower(c));
#endif
    return out_text.rfind(root_text, 0) == 0;
}

static std::vector<char> read_file(const fs::path& path) {
    std::ifstream file(path, std::ios::binary);
    return {std::istreambuf_iterator<char>(file), std::istreambuf_iterator<char>()};
}

static void send_all(socket_t client, const std::string& data) {
    const char* ptr = data.data();
    size_t remaining = data.size();
    while (remaining > 0) {
        int sent = send(client, ptr, static_cast<int>(remaining), 0);
        if (sent <= 0) return;
        ptr += sent;
        remaining -= static_cast<size_t>(sent);
    }
}

static void send_all(socket_t client, const std::vector<char>& data) {
    const char* ptr = data.data();
    size_t remaining = data.size();
    while (remaining > 0) {
        int sent = send(client, ptr, static_cast<int>(remaining), 0);
        if (sent <= 0) return;
        ptr += sent;
        remaining -= static_cast<size_t>(sent);
    }
}

static void send_response(socket_t client, int code, const std::string& reason,
                          const std::string& type, const std::vector<char>& body,
                          bool no_cache) {
    std::ostringstream headers;
    headers << "HTTP/1.1 " << code << ' ' << reason << "\r\n"
            << "Content-Length: " << body.size() << "\r\n"
            << "Content-Type: " << type << "\r\n"
            << "Access-Control-Allow-Origin: *\r\n"
            << "Date: " << http_date() << "\r\n";
    if (no_cache) {
        headers << "Cache-Control: no-store, no-cache, must-revalidate, max-age=0\r\n";
    } else {
        headers << "Cache-Control: public, max-age=60\r\n";
    }
    headers << "Connection: close\r\n\r\n";
    send_all(client, headers.str());
    send_all(client, body);
}

static void handle_client(socket_t client, Config config) {
    char buffer[4096] = {};
    int received = recv(client, buffer, sizeof(buffer) - 1, 0);
    if (received <= 0) {
        close_socket(client);
        return;
    }

    std::istringstream request(std::string(buffer, static_cast<size_t>(received)));
    std::string method;
    std::string path;
    request >> method >> path;

    if (method != "GET" && method != "HEAD") {
        std::string text = "Method not allowed\n";
        send_response(client, 405, "Method Not Allowed", "text/plain",
                      std::vector<char>(text.begin(), text.end()), true);
        close_socket(client);
        return;
    }

    fs::path root = config.web_dir;
    std::string file_path = path;
    if (path.rfind("/hls/", 0) == 0) {
        root = config.hls_dir;
        file_path = path.substr(4);
    }

    fs::path resolved;
    if (!safe_join(root, file_path, resolved) || !fs::exists(resolved) || fs::is_directory(resolved)) {
        std::string text = "Not found\n";
        send_response(client, 404, "Not Found", "text/plain",
                      std::vector<char>(text.begin(), text.end()), true);
        close_socket(client);
        return;
    }

    auto body = method == "HEAD" ? std::vector<char>{} : read_file(resolved);
    const bool no_cache = resolved.extension() == ".m3u8" || resolved.extension() == ".ts";
    send_response(client, 200, "OK", content_type(resolved), body, no_cache);
    close_socket(client);
}

static int run_http_server(Config config) {
#ifdef RTSP_LIVE_VIEW_WINDOWS
    WSADATA data;
    if (WSAStartup(MAKEWORD(2, 2), &data) != 0) {
        std::cerr << "WSAStartup failed\n";
        return 1;
    }
#endif

    socket_t server = socket(AF_INET, SOCK_STREAM, 0);
    if (server == invalid_socket_value) {
        std::cerr << "Could not create server socket\n";
        return 1;
    }

    int yes = 1;
    setsockopt(server, SOL_SOCKET, SO_REUSEADDR, reinterpret_cast<const char*>(&yes), sizeof(yes));

    sockaddr_in address{};
    address.sin_family = AF_INET;
    address.sin_port = htons(static_cast<uint16_t>(config.port));
    address.sin_addr.s_addr = config.host == "0.0.0.0" ? INADDR_ANY : inet_addr(config.host.c_str());

    if (bind(server, reinterpret_cast<sockaddr*>(&address), sizeof(address)) < 0) {
        std::cerr << "Could not bind to " << config.host << ':' << config.port << "\n";
        close_socket(server);
        return 1;
    }

    if (listen(server, 32) < 0) {
        std::cerr << "Could not listen on port " << config.port << "\n";
        close_socket(server);
        return 1;
    }

    std::cout << "Player: http://localhost:" << config.port << "\n";
    while (g_running.load()) {
        sockaddr_in client_address{};
#ifdef RTSP_LIVE_VIEW_WINDOWS
        int length = sizeof(client_address);
#else
        socklen_t length = sizeof(client_address);
#endif
        socket_t client = accept(server, reinterpret_cast<sockaddr*>(&client_address), &length);
        if (client == invalid_socket_value) continue;
        std::thread(handle_client, client, config).detach();
    }

    close_socket(server);
#ifdef RTSP_LIVE_VIEW_WINDOWS
    WSACleanup();
#endif
    return 0;
}

static std::string build_ffmpeg_command(const Config& config) {
    fs::create_directories(config.hls_dir);
    const auto playlist = (config.hls_dir / "stream.m3u8").string();
    const auto segment = (config.hls_dir / "segment_%05d.ts").string();

    std::ostringstream cmd;
    cmd << shell_quote(config.ffmpeg)
        << " -hide_banner -loglevel warning"
        << " -rtsp_transport tcp -timeout 5000000"
        << " -fflags nobuffer -flags low_delay"
        << " -i " << shell_quote(config.rtsp_url)
        << " -an"
        << " -c:v libx264 -preset veryfast -tune zerolatency"
        << " -profile:v baseline -pix_fmt yuv420p"
        << " -g 30 -keyint_min 30 -sc_threshold 0"
        << " -f hls"
        << " -hls_time " << config.segment_seconds
        << " -hls_list_size " << config.list_size
        << " -hls_flags delete_segments+independent_segments+omit_endlist"
        << " -hls_segment_filename " << shell_quote(segment)
        << ' ' << shell_quote(playlist);
    return cmd.str();
}

static void run_stream_loop(Config config) {
    while (g_running.load()) {
        const auto command = build_ffmpeg_command(config);
        std::cout << "Starting FFmpeg pipeline\n";
        int code = std::system(command.c_str());
        if (!g_running.load()) break;
        std::cerr << "FFmpeg exited with code " << code
                  << "; retrying in " << config.retry_seconds << " seconds\n";
        std::this_thread::sleep_for(std::chrono::seconds(config.retry_seconds));
    }
}

static void print_usage() {
    std::cout
        << "Usage: rtsp_live_view [options]\n\n"
        << "By default, the RTSP URL is read from stream_url.txt.\n"
        << "You can still override it with --rtsp <url>.\n\n"
        << "Options:\n"
        << "  --rtsp <url>          RTSP URL override\n"
        << "  --rtsp-file <path>    File containing RTSP URL, default: stream_url.txt\n"
        << "  --ffmpeg <path>       FFmpeg executable path, default: ffmpeg\n"
        << "  --host <ip>           Bind address, default: 0.0.0.0\n"
        << "  --port <port>         HTTP port, default: 8080\n"
        << "  --hls-dir <path>      HLS output directory, default: out/hls\n"
        << "  --web-dir <path>      Static UI directory, default: web\n"
        << "  --segment-seconds <n> HLS segment length, default: 1\n"
        << "  --list-size <n>       Playlist segment count, default: 4\n"
        << "  --retry-seconds <n>   Restart delay after FFmpeg exits, default: 3\n";
}

static bool parse_args(int argc, char** argv, Config& config) {
    std::map<std::string, std::string*> strings{
        {"--rtsp", &config.rtsp_url},
        {"--ffmpeg", &config.ffmpeg},
        {"--host", &config.host},
    };

    for (int i = 1; i < argc; ++i) {
        std::string arg = argv[i];
        auto need_value = [&]() -> std::string {
            if (i + 1 >= argc) {
                throw std::runtime_error("Missing value for " + arg);
            }
            return argv[++i];
        };

        if (strings.count(arg)) {
            *strings[arg] = need_value();
        } else if (arg == "--port") {
            config.port = std::stoi(need_value());
        } else if (arg == "--hls-dir") {
            config.hls_dir = need_value();
        } else if (arg == "--web-dir") {
            config.web_dir = need_value();
        } else if (arg == "--rtsp-file") {
            config.rtsp_file = need_value();
        } else if (arg == "--segment-seconds") {
            config.segment_seconds = std::stoi(need_value());
        } else if (arg == "--list-size") {
            config.list_size = std::stoi(need_value());
        } else if (arg == "--retry-seconds") {
            config.retry_seconds = std::stoi(need_value());
        } else if (arg == "--help" || arg == "-h") {
            print_usage();
            return false;
        } else {
            throw std::runtime_error("Unknown argument: " + arg);
        }
    }

    if (config.rtsp_url.empty()) {
        if (read_first_line(config.rtsp_file, config.rtsp_url)) {
            std::cout << "Loaded RTSP URL from " << config.rtsp_file << "\n";
        }
    }

    if (config.rtsp_url.empty()) {
        std::cerr << "No RTSP URL configured. Put it in " << config.rtsp_file
                  << " or pass --rtsp <url>.\n\n";
        print_usage();
        return false;
    }

    if (is_placeholder_rtsp_url(config.rtsp_url)) {
        std::cerr << "stream_url.txt still contains the sample RTSP URL. Replace it with your real camera URL.\n";
        return false;
    }
    return true;
}

static void on_signal(int) {
    g_running.store(false);
}

int main(int argc, char** argv) {
    Config config;
    try {
        if (!parse_args(argc, argv, config)) return config.rtsp_url.empty() ? 1 : 0;
    } catch (const std::exception& error) {
        std::cerr << error.what() << "\n";
        print_usage();
        return 1;
    }

    std::signal(SIGINT, on_signal);
    std::signal(SIGTERM, on_signal);

    fs::create_directories(config.hls_dir);
    std::cout << "HLS output: " << config.hls_dir << "\n";

    std::thread stream_thread(run_stream_loop, config);
    int server_code = run_http_server(config);

    g_running.store(false);
    if (stream_thread.joinable()) stream_thread.join();
    return server_code;
}
