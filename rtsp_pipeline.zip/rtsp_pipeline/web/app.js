const video = document.getElementById("video");
const statusText = document.getElementById("status");
const reloadButton = document.getElementById("reload");
const source = "/hls/stream.m3u8";

let hls;

function setStatus(text) {
  statusText.textContent = text;
}

function destroyPlayer() {
  if (hls) {
    hls.destroy();
    hls = undefined;
  }
  video.removeAttribute("src");
  video.load();
}

function startPlayer() {
  destroyPlayer();
  setStatus("Connecting");

  if (video.canPlayType("application/vnd.apple.mpegurl")) {
    video.src = source;
    video.play().catch(() => setStatus("Tap play to start"));
    return;
  }

  if (!window.Hls || !window.Hls.isSupported()) {
    setStatus("HLS is not supported in this browser");
    return;
  }

  hls = new Hls({
    lowLatencyMode: true,
    liveSyncDurationCount: 2,
    maxLiveSyncPlaybackRate: 1.5,
  });

  hls.on(Hls.Events.MANIFEST_PARSED, () => {
    setStatus("Live");
    video.play().catch(() => setStatus("Tap play to start"));
  });

  hls.on(Hls.Events.ERROR, (_, data) => {
    if (!data.fatal) return;
    setStatus("Reconnecting");
    if (data.type === Hls.ErrorTypes.NETWORK_ERROR) {
      hls.startLoad();
    } else {
      setTimeout(startPlayer, 1200);
    }
  });

  hls.loadSource(source);
  hls.attachMedia(video);
}

video.addEventListener("playing", () => setStatus("Live"));
video.addEventListener("waiting", () => setStatus("Buffering"));
video.addEventListener("error", () => setStatus("Playback error"));
reloadButton.addEventListener("click", startPlayer);

startPlayer();

