# RTSP Live View Pipeline

This project converts an RTSP camera stream into a browser and mobile friendly live view. The C++ service supervises FFmpeg, writes a short rolling HLS playlist, and serves both the player UI and HLS segments over HTTP.

## Architecture

```text
RTSP camera
  -> C++ supervisor
  -> FFmpeg transcode/package
  -> rolling HLS playlist
  -> built-in HTTP server
  -> web or mobile browser
```

The implementation uses HLS because it works in Safari/iOS natively and in Chromium/Firefox through `hls.js`. For sub-second latency, WebRTC is the better protocol, but HLS is simpler to operate and easier to validate across browsers.

## Requirements

- `g++` with C++17 support
- FFmpeg with `libx264`
- A reachable RTSP URL

## Build

On Windows:

```powershell
.\build.ps1
```

If PowerShell blocks local scripts, use:

```powershell
powershell -ExecutionPolicy Bypass -File .\build.ps1
```

Or run `g++` directly:

```powershell
New-Item -ItemType Directory -Force -Path build
g++ -std=c++17 -O2 -Wall -Wextra -pedantic src/main.cpp -lws2_32 -o build/rtsp_live_view.exe
```

On Linux/macOS:

```bash
mkdir -p build
g++ -std=c++17 -O2 -Wall -Wextra -pedantic src/main.cpp -o build/rtsp_live_view
```

## Run

On Windows:

```powershell
.\build\rtsp_live_view.exe
```

On Linux/macOS:

```bash
./build/rtsp_live_view
```

By default the app reads the camera URL from `stream_url.txt`. Put one RTSP URL on the first line:

```text
rtsp://user:pass@camera-host/path
```

Replace that sample with the real URL from your camera. If the sample value is still present, the app exits with a clear message instead of trying to stream from a fake address.

You can still override the file from the command line:

```powershell
.\build\rtsp_live_view.exe --rtsp "rtsp://user:pass@camera-host/path"
```

Use double quotes around the RTSP URL on Windows when using the flag. Single quotes may be passed through to `cmd.exe` literally by some launch paths.

Then open:

```text
http://localhost:8080
```

For phone testing, put the computer and phone on the same network, allow the selected port through the firewall, and open:

```text
http://<computer-lan-ip>:8080
```

## Useful Options

```text
--rtsp <url>          RTSP URL override
--rtsp-file <path>    File containing RTSP URL, default stream_url.txt
--ffmpeg <path>       FFmpeg executable path
--host <ip>           Bind address, default 0.0.0.0
--port <port>         HTTP port, default 8080
--hls-dir <path>      HLS output directory, default out/hls
--web-dir <path>      Static UI directory, default web
--segment-seconds <n> HLS segment length, default 1
--list-size <n>       Playlist segment count, default 4
--retry-seconds <n>   Restart delay after FFmpeg exits, default 3
```

## Latency

Expected glass-to-glass latency with the default HLS settings is usually 3-6 seconds on a stable LAN. The main contributors are RTSP jitter, encoder GOP size, HLS segment length, playlist depth, player buffering, and mobile browser autoplay policies.

Lower latency tuning:

- Keep `--segment-seconds 1`
- Keep `--list-size 3` or `4`
- Use a camera profile with H.264 and a short keyframe interval
- Prefer wired camera/network paths where possible
- Use WebRTC instead of HLS when the target is below 1 second

## Failure Handling

The C++ service restarts FFmpeg when the stream exits. HLS playlists and segments are served with no-cache headers, and the browser player reconnects on fatal network or decode errors.

Production improvements:

- Replace `std::system` with managed child processes for graceful shutdown
- Add health endpoints and metrics
- Rotate structured logs
- Validate RTSP URLs before launch
- Add authentication for the player and stream endpoints

## Scaling Notes

Python orchestration with FFmpeg or GStreamer is sufficient for many deployments because the expensive work is media encoding, packetization, and I/O, which already happens in native libraries. Python is often productive for scheduling, health checks, API integration, and fleet management.

Moving orchestration to C++ can improve startup overhead, memory use, binary packaging, and tighter process control. It can also help if the service embeds GStreamer directly, uses zero-copy hardware paths, or handles thousands of long-lived sessions per host. The trade-off is more complex code, slower iteration, and higher risk around memory/process lifecycle bugs.

Recommendation: keep FFmpeg/GStreamer as the media engine either way. Use Python if the system is mostly control-plane orchestration. Use C++ when the node is a performance-sensitive edge service, when direct GStreamer integration is required, or when deployment needs a small self-contained binary. For web/mobile delivery at scale, pair the edge service with a CDN or media server layer rather than opening one transcoder per viewer.
